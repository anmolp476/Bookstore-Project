//Deep Patel

package bookstoreapplication.GUIs;

import bookstoreapplication.Viewable;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author deeps
 */
public class ApplicationGUI implements Viewable{
    
    public void accessUI(Stage primaryStage) {}
}
