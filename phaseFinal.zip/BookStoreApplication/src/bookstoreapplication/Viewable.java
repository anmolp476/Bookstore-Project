/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bookstoreapplication;

/**
 *
 * @author Victor
 */
import javafx.stage.Stage;

public interface Viewable {
    void accessUI(Stage primaryStage);
}

